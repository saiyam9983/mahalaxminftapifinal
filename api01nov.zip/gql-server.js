// import { ApolloServer } from "apollo-server-express";
// import dotenv from "dotenv"
// dotenv.config()

// const apolloServer = new ApolloServer({
//   typeDefs,
//   resolvers,
// });

// apolloServer.listen(process.env.PORT, () => {
//   console.log(`🚀 GRAPHQL Server is running at http://localhost:${process.env.PORT}`);
// });
