const url =
  "mongodb+srv://saiyam:xbKOCfFq2BZJXUMl@cluster0.pyj4fl9.mongodb.net/";
export default url;
