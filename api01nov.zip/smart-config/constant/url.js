export const IPFS_URL = "https://cf-ipfs";
export const GRAPHQL_API = "http://192.168.0.64:5000";
export const TRANSAK_API = "36da2bff-64b1-4265-a117-85e2644ed0ad";
