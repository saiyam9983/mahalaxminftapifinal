const a = {
  collection: "Rugby",
  teams: [
    {
      team1: [
        {
          name: "Riitk",
        },
        {
          name: "ERT",
        },
        {
          name: "SSS",
        },
      ],
    },
  ],
};
